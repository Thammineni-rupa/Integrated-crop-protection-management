package com.example.agro_doc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
