import 'dart:ui';

import 'package:flutter/material.dart';

Color kprimaryColor = const Color(0xffFEE9CE);
Color ksecondaryColor = const Color(0xffFEE9CE);
Color kbuttonColor = const Color(0xff1E1E1E);
Color kWhite = const Color(0xffFFFFFF);

Image kcircles = Image.asset('assets/image.png');
