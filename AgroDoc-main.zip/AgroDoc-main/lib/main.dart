import 'package:AgroDoc/firebase_options.dart';
import 'package:AgroDoc/presentation/bindings/auth_bindings.dart';
import 'package:AgroDoc/presentation/bindings/crop_prediction_bindings.dart';
import 'package:AgroDoc/presentation/bindings/fertilizer_bindings.dart';
import 'package:AgroDoc/presentation/bindings/home_bindings.dart';
import 'package:AgroDoc/presentation/bindings/nearby_store_bindings.dart';
import 'package:AgroDoc/presentation/bindings/pest_disease_bindings.dart';
import 'package:AgroDoc/presentation/pages/authentication.dart';
import 'package:AgroDoc/presentation/pages/crop_recommendation.dart';
import 'package:AgroDoc/presentation/pages/fertilizer_recommendation.dart';
import 'package:AgroDoc/presentation/pages/home.dart';
import 'package:AgroDoc/presentation/pages/nearby_store.dart';
import 'package:AgroDoc/presentation/pages/pest_disease_detection.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

void main() async {
  FlutterError.onError = (FlutterErrorDetails details) {
    FlutterError.dumpErrorToConsole(details);
  };

  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Agro Doc',
      theme: ThemeData(
          primarySwatch: Colors.pink,
          primaryColor: const Color(0xffFEE9CE),
          // font family for the entire app is set to Poppins
          fontFamily: 'Poppins',
          textButtonTheme: TextButtonThemeData(
            style: TextButton.styleFrom(
              foregroundColor: Colors.white,
              backgroundColor: const Color(0xff00BDD5),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
          ),
          textTheme: const TextTheme(
            displayLarge: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
            displayMedium: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
            displaySmall: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
            headlineMedium: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
            headlineSmall: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
            titleLarge: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.bold,
              color: Colors.black,
            ),
            bodyLarge: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.normal,
              color: Colors.black,
            ),
            bodyMedium: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.normal,
              color: Colors.black,
            ),
          )),
      initialRoute: '/authentication',
      getPages: [
        GetPage(
          name: '/authentication',
          page: () => const Authentication(),
          binding: AuthBindings(),
        ),
        // home page
        GetPage(
          name: '/home',
          page: () => const Home(),
          binding: HomeBindings(),
        ),
        GetPage(
          name: '/crop-recommendation',
          page: () => const CropRecommendation(),
          binding: CropPredictionBindings(),
        ),
        GetPage(
          name: '/fertilizer-recommendation',
          page: () => const FertilizerRecommendation(),
          binding: FertilizerBinding(),
        ),
        GetPage(
          name: '/pest-disease-detection',
          page: () => const PestDiseaseDetection(),
          binding: PestDiseaseBindings(),
        ),
        GetPage(
          name: '/nearby-store-locator',
          page: () => const NearbyStore(),
          binding: NearbyStoreBindings(),
        ),
      ],
    );
  }
}
