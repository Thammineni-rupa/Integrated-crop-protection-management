// form input feilds for the app

import 'package:flutter/material.dart';

Widget inputFeild({
  required String hintText,
  required TextEditingController controller,
  required TextInputType keyboardType,
}) {
  return Padding(
    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
    child: TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      decoration: InputDecoration(
        hintText: hintText,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
        ),
      ),
    ),
  );
}