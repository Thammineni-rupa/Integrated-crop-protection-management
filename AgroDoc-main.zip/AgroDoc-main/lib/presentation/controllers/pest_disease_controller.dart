// lib/presentation/controllers/pest_disease_controller.dart
import 'dart:convert';
import 'dart:io';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;

class PestDiseaseController extends GetxController {
  // Bunny.net Storage Endpoint and API Key
  final String storageEndpoint =
      'https://storage.bunnycdn.com/agrodoc'; // Replace with your own storage endpoint
  final String apiAccessKey = '010240db-d75d-4093-819d3bad8549-3630-4384';

  // Flask API URL
  final String flaskApiUrl = 'https://pest-disease-api.onrender.com/predict';

  // Observable for loading state and status message
  var isLoading = false.obs;
  var statusMessage = ''.obs;
  // render the image from the image picker
  var uploadedImage = ''.obs;

  final ImagePicker _picker = ImagePicker();

  // Function to upload the image to Bunny.net
  Future<String> uploadToBunnyNet(File imageFile, String fileName) async {
    final url = Uri.parse('$storageEndpoint/$fileName');
    final headers = {
      'AccessKey': apiAccessKey,
      'Content-Type': 'application/octet-stream',
    };

    try {
      final fileBytes = await imageFile.readAsBytes();
      final response = await http.put(url, headers: headers, body: fileBytes);

      isLoading.value = false;

      if (response.statusCode == 201) {
        // Return the full URL of the uploaded image
        uploadedImage.value = 'https://agrodoc.b-cdn.net/$fileName';
        return 'https://agrodoc.b-cdn.net/$fileName';
      } else {
        throw Exception(
            'Failed to upload image to Bunny.net: ${response.statusCode}');
      }
    } catch (e) {
      throw Exception('Error uploading to Bunny.net: $e');
    }
  }

  // Function to send the image URL to the Flask API
  Future<void> sendImageUrlToFlask(String imageUrl) async {
    try {
      final response = await http.post(
        Uri.parse(flaskApiUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'image_url': imageUrl}),
      );

      if (response.statusCode != 200) {
        throw Exception(
            'Error sending data to Flask API: ${response.statusCode}');
      } else if (response.body.isEmpty) {
        throw Exception('No response from Flask API');
      } else {
        statusMessage.value = jsonDecode(response.body)['prediction'];
      }
    } catch (e) {
      throw Exception('Error communicating with Flask API: $e');
    }
  }

  // Function to pick an image, upload it to Bunny.net, and send the URL to Flask API
  Future<void> uploadAndSendImage() async {
    try {
      final XFile? pickedImage =
          await _picker.pickImage(source: ImageSource.gallery);

      if (pickedImage == null) {
        statusMessage.value = 'No image selected';
        return;
      }

      final File imageFile = File(pickedImage.path);
      final String fileName =
          DateTime.now().millisecondsSinceEpoch.toString() + '.jpg';

      statusMessage.value = 'Uploading image to Bunny.net...';

      isLoading.value = true;

      // Upload image to Bunny.net
      final String imageUrl = await uploadToBunnyNet(imageFile, fileName);

      statusMessage.value = 'Image uploaded to Bunny.net: $imageUrl';

      // Send image URL to Flask API
      statusMessage.value = 'Sending image URL to Flask API...';
      statusMessage.value = 'Image URL sent to Flask API successfully!';
      await sendImageUrlToFlask(imageUrl);
    } catch (e) {
      statusMessage.value = 'Error: $e';
    } finally {
      isLoading.value = false;
    }
  }
}
