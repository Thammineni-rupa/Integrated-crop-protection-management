// lib/presentation/controllers/home_controller.dart

import 'package:AgroDoc/presentation/controllers/auth_controller.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';

class HomeController extends GetxController {
  var userName = ''.obs;
  var currentUser = FirebaseAuth.instance.currentUser;

  @override
  void onInit() {
    super.onInit();
    final user = Get.find<AuthController>().firebaseUser.value;
    if (user != null) {
      userName.value = user.displayName!;
    }
  }

  void signOut() {
    FirebaseAuth.instance.signOut();
    currentUser = null;
    Get.offAllNamed('/authentication');
  }
}
