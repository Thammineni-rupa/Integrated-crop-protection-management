// lib/presentation/bindings/crop_prediction_bindings.dart

import 'package:firebase_auth/firebase_auth.dart';
import 'package:get/get.dart';
import 'package:google_sign_in/google_sign_in.dart';

class AuthController extends GetxController {
  // Add your state and logic here
  final FirebaseAuth firebaseAuth = FirebaseAuth.instance;

  final Rx<User?> firebaseUser = Rx<User?>(FirebaseAuth.instance.currentUser);

  // signInWithGoogle
  // google sign in
  Future<void> signInWithGoogle() async {
    try {
      final GoogleSignInAccount? googleUser = await GoogleSignIn().signIn();

      if (googleUser == null) {
        // If the user cancels the sign-in
        throw Exception('Google sign in aborted');
      }

      final GoogleSignInAuthentication googleAuth =
          await googleUser.authentication;

      // create a new credential
      final AuthCredential credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      // sign in to firebase with the google user credential
      final UserCredential authResult =
          await firebaseAuth.signInWithCredential(credential);

      // Retrieve user details from Firestore or create a new record
      final user = authResult.user;

      // update the user state
      firebaseUser.value = user;
      if (user != null) {
        Get.offAllNamed('/home');
      } else {
        throw Exception('Google sign in failed');
      }
    } catch (e) {
      Get.snackbar('error', e.toString());
    }
  }
}
