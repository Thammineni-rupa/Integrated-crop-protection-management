// lib/presentation/controllers/nearby_store_locator.dart
import 'package:get/get.dart';

class Place {
  final String name;
  final List<String> stores;

  Place(this.name, this.stores);
}

class NearbyStoreLocator extends GetxController {
  var selectedPlace = 'Kempagouda'.obs;
  var stores = <String>[].obs;

  var places = <Place>[
    Place('Kempagouda', [
      'Laxmi Fertilizers',
      'Ganesh Fertilizers',
      'Venkateswar Fertilizers',
    ]),
    Place('Malleswaram', [
      'Sai Supermart',
      'Ravi Book Store',
      'Shiva Stationary',
    ]),
    Place('Rajajinagar', [
      'Rajajinagar Veg Market',
      'Prakash Fertilizers',
      'Super Star Electronics',
    ]),
    Place('Marthahalli', [
      'Techno Mart',
      'Dine and Shop',
      'Super Electronics',
    ]),
    Place('Whitefield', [
      'Green Valley Mart',
      'Central Books',
      'Super Bakery',
    ]),
    Place('Sarjapura', [
      'Fruits and Veg',
      'Kiran General Store',
      'Hardware Mart',
    ]),
    Place('HSR Layout', [
      'HSR Supermarket',
      'Vishal Book Store',
      'HSR Stationary Shop',
    ]),
    Place('Silk Board', [
      'Silk Board Fertilizers',
      'City Electronics',
      'Pooja General Store',
    ]),
    Place('Mahadevapura', [
      'Maya Mall',
      'Classic Book Store',
      'Fruits World',
    ]),
    Place('Krishnarajapuram', [
      'Raja Supermart',
      'Ravi Fertilizers',
      'Krishna Hardware',
    ]),
  ].obs;

  var selectedLocation = ''.obs;
  var selectedStores = <String>[].obs;

  void selectLocation(String location) {
    selectedLocation.value = location;
    selectedStores.assignAll(
      places.firstWhere((place) => place.name == location).stores,
    );
  }
}
