// lib/presentation/controllers/fertilizer_recommendation_controller.dart

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

class FertilizerRecommendationController extends GetxController {
  final temperatureController = TextEditingController();
  final humidityController = TextEditingController();
  final moistureController = TextEditingController();
  // n,p,k controllers
  final nController = TextEditingController();
  final pController = TextEditingController();
  final kController = TextEditingController();
  final soilType = 'Black'.obs;
  final cropType = 'Barley'.obs;

  final List<String> soilTypes = ['Black', 'Clayey', 'Loamy', 'Red', 'Sandy'];
  final List<String> cropTypes = [
    'Barley',
    'Cotton',
    'Groundnut',
    'Maize',
    'Millets',
    'Oilseeds',
    'Paddy',
    'Pulses',
    'Sugarcane',
    'Wheat'
  ];

  final RxString cropPredictionError = ''.obs;
  final RxString cropPredictionResult = ''.obs;
  var isFertilizerPredictionLoading = false.obs;
  var isFertilizerPredictionError = false.obs;
  var fertilizerPredictionResult = ''.obs;
  var fertilizerPredictionError = ''.obs;

  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onClose() {
    temperatureController.dispose();
    humidityController.dispose();
    moistureController.dispose();
    super.onClose();
  }

  Future<void> runModel() async {
    final temperature = double.parse(temperatureController.text);
    final humidity = double.parse(humidityController.text);
    final moisture = double.parse(moistureController.text);
    final n = double.parse(nController.text);
    final p = double.parse(pController.text);
    final k = double.parse(kController.text);
    final soil = soilType.value;
    final crop = cropType.value;

    // post the data to the api
    // API endpoint
    const String apiUrl =
        "https://fertilizer-recomendation-api-2.onrender.com/predict"; // Replace with your Flask API URL

    // Prepare data for the POST request
    try {
      isFertilizerPredictionLoading.value = true;
      Get.defaultDialog(
        title: 'Loading',
        content: const CircularProgressIndicator(),
      );
      final Map<String, dynamic> requestData = {
        "temp": temperature,
        "humidity": humidity,
        "moisture": moisture,
        "soil_type": soil,
        "crop_type": crop,
        "nitrogen": n,
        "potassium": p,
        "phosphorous": k,
      };
      print(requestData);
      // make the post request
      final response = await http.post(
        Uri.parse(apiUrl),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(requestData),
      );
      final Map<String, dynamic> data = jsonDecode(response.body);
      print(data);
      if (response.statusCode == 200) {
        Get.back();
        isFertilizerPredictionLoading.value = false;
        fertilizerPredictionResult.value = data['fertilizer'];
      } else {
        Get.back();
        cropPredictionError.value = 'error';
      }
    } catch (e) {
      Get.back();
      Get.snackbar('Error', 'An error occurred. Please try again later');
    }
  }
}
