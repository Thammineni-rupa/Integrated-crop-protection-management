// lib/presentation/controllers/crop_prediction_ml_controller.dart

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

class CropPredictionMLController extends GetxController {
  // final TextEditingController cropNameController = TextEditingController();
  final TextEditingController temperatureController = TextEditingController();
  final TextEditingController humidityController = TextEditingController();
  final TextEditingController rainfallController = TextEditingController();
  final TextEditingController phController = TextEditingController();
  final TextEditingController nController = TextEditingController();
  final TextEditingController pController = TextEditingController();
  final TextEditingController kController = TextEditingController();
  // final TextEditingController soilTypeController = TextEditingController();
  // final TextEditingController temperatureMinController = TextEditingController();
  // final TextEditingController temperatureMaxController = TextEditingController();
  // final TextEditingController humidityMinController = TextEditingController();
  // final TextEditingController humidityMaxController = TextEditingController();
  // final TextEditingController rainfallMinController = TextEditingController();
  // final TextEditingController rainfallMaxController = TextEditingController();
  // final TextEditingController phMinController = TextEditingController();
  // final TextEditingController phMaxController = TextEditingController();
  // final TextEditingController nMinController = TextEditingController();
  // final TextEditingController nMaxController = TextEditingController();
  // final TextEditingController pMinController = TextEditingController();
  // final TextEditingController pMaxController = TextEditingController();
  // final TextEditingController kMinController = TextEditingController();
  // final TextEditingController kMaxController = TextEditingController();

  // reactive variables
  final RxBool isCropPredictionLoading = false.obs;
  final RxBool isCropPredictionError = false.obs;
  final RxString cropPredictionError = ''.obs;
  final RxString cropPredictionResult = ''.obs;
  var output = [].obs;
  var isLoading = false.obs;

  @override
  void onClose() {
    // cropNameController.dispose();
    temperatureController.dispose();
    humidityController.dispose();
    rainfallController.dispose();
    phController.dispose();
    nController.dispose();
    pController.dispose();
    kController.dispose();
    // soilTypeController.dispose();
    // temperatureMinController.dispose();
    // temperatureMaxController.dispose();
    // humidityMinController.dispose();
    // humidityMaxController.dispose();
    // rainfallMinController.dispose();
    // rainfallMaxController.dispose();
    // phMinController.dispose();
    // phMaxController.dispose();
    // nMinController.dispose();
    // nMaxController.dispose();
    // pMinController.dispose();
    // pMaxController.dispose();
    // kMinController.dispose();
    // kMaxController.dispose();
    super.onClose();
  }

  // API endpoint
  final String apiUrl =
      "https://crop-recommendation-api-2.onrender.com/api/predict"; // Replace with your Flask API URL

  // Function to run the prediction model
  Future<void> runModel() async {
    try {
      isCropPredictionLoading.value = true;
      isCropPredictionError.value = false;
      cropPredictionResult.value = '';
      isLoading.value = true;

      // Prepare data for the POST request
      final Map<String, dynamic> requestData = {
        "N": double.parse(nController.text),
        "P": double.parse(pController.text),
        "K": double.parse(kController.text),
        "temperature": double.parse(temperatureController.text),
        "humidity": double.parse(humidityController.text),
        "ph": double.parse(phController.text),
        "rainfall": double.parse(rainfallController.text),
      };

      // Send POST request
      final response = await http.post(
        Uri.parse(apiUrl),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode(requestData),
      );

      if (response.statusCode == 200) {
        // Parse the prediction result
        final Map<String, dynamic> responseData = jsonDecode(response.body);
        cropPredictionResult.value = responseData['prediction'];
        isLoading.value = false;
      } else {
        // Handle API error
        cropPredictionError.value = "Error: ${response.reasonPhrase}";
        isCropPredictionError.value = true;
      }
    } catch (e) {
      cropPredictionError.value = "Error: $e";
      isCropPredictionError.value = true;
    } finally {
      isCropPredictionLoading.value = false;
    }
  }

  // run the prediction model
  // Future<void> runModel() async {
  //   isCropPredictionLoading.value = true;
  //   isCropPredictionError.value = false;
  //   cropPredictionError.value = '';
  //   cropPredictionResult.value = '';

  //   try {
  //     final input = [
  //       double.parse(temperatureController.text),
  //       double.parse(humidityController.text),
  //       double.parse(rainfallController.text),
  //       double.parse(phController.text),
  //       double.parse(nController.text),
  //       double.parse(pController.text),
  //       double.parse(kController.text),
  //       // double.parse(temperatureMinController.text),
  //       // double.parse(temperatureMaxController.text),
  //       // double.parse(humidityMinController.text),
  //       // double.parse(humidityMaxController.text),
  //       // double.parse(rainfallMinController.text),
  //       // double.parse(rainfallMaxController.text),
  //       // double.parse(phMinController.text),
  //       // double.parse(phMaxController.text),
  //       // double.parse(nMinController.text),
  //       // double.parse(nMaxController.text),
  //       // double.parse(pMinController.text),
  //       // double.parse(pMaxController.text),
  //       // double.parse(kMinController.text),
  //       // double.parse(kMaxController.text),
  //     ];

  //     _interpreter.run(input, output);
  //     print(_interpreter.getInputTensors());
  //     cropPredictionResult.value = output.toString();
  //   } catch (e) {
  //     isCropPredictionError.value = true;
  //     cropPredictionError.value = e.toString();
  //   } finally {
  //     isCropPredictionLoading.value = false;
  //   }
  // }

  // send a post request to the server
  // send data to an api
}
