// lib/presentation/bindings/nearby_store_bindings.dart
import 'package:AgroDoc/presentation/controllers/nearby_store_locator.dart';
import 'package:get/get.dart';

class NearbyStoreBindings extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<NearbyStoreLocator>(() => NearbyStoreLocator());
  }
}