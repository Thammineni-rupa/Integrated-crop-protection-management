// lib/presentation/bindings/pest_disease_bindings.dart

import 'package:AgroDoc/presentation/controllers/pest_disease_controller.dart';
import 'package:get/get.dart';

class PestDiseaseBindings extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<PestDiseaseController>(() => PestDiseaseController());
  }
}