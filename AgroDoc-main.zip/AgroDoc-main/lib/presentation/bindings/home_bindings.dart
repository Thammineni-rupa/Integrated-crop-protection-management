// lib/presentation/binding/home_bindings.dart

import 'package:AgroDoc/presentation/controllers/home_controller.dart';
import 'package:get/get.dart';

class HomeBindings extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<HomeController>(() => HomeController());
  }
}