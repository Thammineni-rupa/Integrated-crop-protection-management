// lib/presentation/bindings/fertilizer_bindings.dart

import 'package:AgroDoc/presentation/controllers/fertilizer_recommendation_controller.dart';
import 'package:get/get.dart';


class FertilizerBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<FertilizerRecommendationController>(() => FertilizerRecommendationController());
  }
}