// lib/presentation/bindings/crop_prediction_bindings.dart

import 'package:get/get.dart';
import 'package:AgroDoc/presentation/controllers/crop_recommendation_controller.dart';

class CropPredictionBindings extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<CropPredictionMLController>(() => CropPredictionMLController());
  }
}