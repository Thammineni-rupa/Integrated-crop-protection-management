// lib/presentation/pages/nearby_store.dart

import 'package:AgroDoc/presentation/controllers/nearby_store_locator.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class NearbyStore extends GetView<NearbyStoreLocator> {
  const NearbyStore({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        title: const Text('Store Locator',
            style: TextStyle(color: Colors.white, fontSize: 20)),
        backgroundColor: Colors.green,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Get.back();
          },
        ),
      ),
      body: Obx(
        () => Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              DropdownButton<String>(
                isExpanded: true,
                borderRadius: BorderRadius.circular(10),
                padding: const EdgeInsets.all(20),
                hint: Text('Select Place'),
                value: controller.selectedPlace.value,
                onChanged: (String? newValue) {
                  controller.selectedPlace(newValue);
                  controller.stores.value = controller.places
                      .firstWhere((place) => place.name == newValue)
                      .stores;
                },
                items: controller.places.map((Place place) {
                  return DropdownMenuItem<String>(
                    value: place.name,
                    child: Text(place.name),
                  );
                }).toList(),
              ),
              SizedBox(height: 20),
              if (controller.stores.isNotEmpty)
                Expanded(
                  child: ListView.builder(
                    itemCount: controller.stores.length,
                    itemBuilder: (context, index) {
                      return ListTile(
                        // store names
                        title: Text(controller.stores[index]),
                      );
                    },
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
