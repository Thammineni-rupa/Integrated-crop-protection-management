// lib/presentation/pages/fertilizer_recommendation.dart

import 'package:AgroDoc/presentation/widgets/custom_button.dart';
import 'package:AgroDoc/presentation/widgets/input_feild.dart';
import 'package:AgroDoc/presentation/widgets/output.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:AgroDoc/presentation/controllers/fertilizer_recommendation_controller.dart';

class FertilizerRecommendation
    extends GetView<FertilizerRecommendationController> {
  const FertilizerRecommendation({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        title: const Text('Fertilizer Prediction',
            style: TextStyle(color: Colors.white, fontSize: 20)),
        backgroundColor: Colors.green,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Get.back();
          },
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              inputFeild(
                  hintText: 'Tempeature',
                  controller: controller.temperatureController,
                  keyboardType: TextInputType.number),
              inputFeild(
                  hintText: 'Humidity',
                  controller: controller.humidityController,
                  keyboardType: TextInputType.number),
              // moisture
              inputFeild(
                  hintText: 'Moisture',
                  controller: controller.moistureController,
                  keyboardType: TextInputType.number),
              const SizedBox(height: 10),
              // soi type dropdown
              DropdownButtonFormField<String>(
                decoration: InputDecoration(
                  hintText: 'Soil Type',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                value: controller.soilType.value,
                onChanged: (String? value) {
                  controller.soilType.value = value!;
                },
                items: controller.soilTypes.map((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
              ),
              const SizedBox(height: 20),
              // crop type dropdown
              DropdownButtonFormField<String>(
                decoration: InputDecoration(
                  hintText: 'Crop Type',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                value: controller.cropType.value,
                onChanged: (String? value) {
                  controller.cropType.value = value!;
                },
                items: controller.cropTypes.map((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
              ),
              const SizedBox(height: 10),
              // Nitrogen
              inputFeild(
                  hintText: 'Nitrogen',
                  controller: controller.nController,
                  keyboardType: TextInputType.number),
              // Pottasium
              inputFeild(
                  hintText: 'Pottasium',
                  controller: controller.pController,
                  keyboardType: TextInputType.number),
              // Phosphorus
              inputFeild(
                  hintText: 'Phosphorus',
                  controller: controller.kController,
                  keyboardType: TextInputType.number),
              CustomButton(
                text: 'Predict Fertilizer',
                onPressed: () {
                  controller.runModel();
                },
              ),
              Obx(() {
                if (controller.isFertilizerPredictionLoading.value) {
                  return const CircularProgressIndicator();
                } else if (controller.isFertilizerPredictionError.value) {
                  return outputDisplay(
                      output: controller.fertilizerPredictionError.value,
                      color: Colors.red);
                } else if (controller
                    .fertilizerPredictionResult.value.isNotEmpty) {
                  return outputDisplay(
                      output:
                          'Recommended Fertilizer: ${controller.fertilizerPredictionResult.value}');
                } else {
                  return const SizedBox.shrink();
                }
              }),
            ],
          ),
        ),
      ),
    );
  }
}
