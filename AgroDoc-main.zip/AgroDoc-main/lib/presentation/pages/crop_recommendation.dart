// lib/presentation/pages/crop_prediction.dart

import 'package:AgroDoc/presentation/widgets/custom_button.dart';
import 'package:AgroDoc/presentation/widgets/input_feild.dart';
import 'package:AgroDoc/presentation/widgets/output.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:AgroDoc/presentation/controllers/crop_recommendation_controller.dart';

class CropRecommendation extends GetView<CropPredictionMLController> {
  const CropRecommendation({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        title: const Text('Crop Prediction',
            style: TextStyle(color: Colors.white, fontSize: 20)),
        backgroundColor: Colors.green,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Get.back();
          },
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              inputFeild(
                controller: controller.nController,
                hintText: 'Nitrogen',
                keyboardType: TextInputType.number,
              ),
              inputFeild(
                controller: controller.pController,
                hintText: 'Phosphorus',
                keyboardType: TextInputType.number,
              ),
              inputFeild(
                controller: controller.kController,
                hintText: 'Potassium',
                keyboardType: TextInputType.number,
              ),
              inputFeild(
                controller: controller.temperatureController,
                hintText: 'Temperature',
                keyboardType: TextInputType.number,
              ),
              inputFeild(
                controller: controller.humidityController,
                hintText: 'Humidity',
                keyboardType: TextInputType.number,
              ),
              inputFeild(
                controller: controller.phController,
                hintText: 'PH',
                keyboardType: TextInputType.number,
              ),
              inputFeild(
                controller: controller.rainfallController,
                hintText: 'Rainfall',
                keyboardType: TextInputType.number,
              ),
              CustomButton(
                text: 'Predict Crop',
                onPressed: () {
                  controller.runModel();
                },
              ),
              Obx(() {
                if (controller.isCropPredictionLoading.value) {
                  return const CircularProgressIndicator();
                } else if (controller.isCropPredictionError.value) {
                  return outputDisplay(
                      output: controller.cropPredictionError.value,
                      color: Colors.red);
                } else if (controller.cropPredictionResult.value.isNotEmpty) {
                  return outputDisplay(
                      output: controller.cropPredictionResult.value);
                } else {
                  return const SizedBox.shrink();
                }
              }),
            ],
          ),
        ),
      ),
    );
  }
}
