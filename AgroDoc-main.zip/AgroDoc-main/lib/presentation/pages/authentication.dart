// lib/presentation/pages/authentication.dart

import 'package:AgroDoc/constants/constants.dart';
import 'package:AgroDoc/presentation/controllers/auth_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:chiclet/chiclet.dart';

class Authentication extends GetView<AuthController> {
  const Authentication({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kprimaryColor,
      body: Stack(
        clipBehavior: Clip.none,
        children: [
          Positioned(
            top: 0,
            left: 230,
            child: kcircles,
          ),
          Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Text(
                  'Welcome, Let\'s get started!',
                  style: TextStyle(
                    fontSize: 36,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Poppins',
                  ),
                ),
                const SizedBox(height: 40),
                ChicletAnimatedButton(
                  width: double.infinity,
                  height: 60,
                  backgroundColor: kbuttonColor,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left: 10, right: 10),
                        child: Image.asset(
                          'assets/google.png',
                          width: 46,
                          height: 46,
                        ),
                      ),
                      const Text(
                        'Login with Google',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                        ),
                      ),
                    ],
                  ),
                  onPressed: () {
                    controller.signInWithGoogle();
                  },
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
