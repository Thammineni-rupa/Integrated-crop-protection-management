// lib/presentation/pages/home.dart

import 'package:AgroDoc/constants/constants.dart';
import 'package:AgroDoc/presentation/controllers/home_controller.dart';
import 'package:chiclet/chiclet.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class Home extends GetView<HomeController> {
  const Home({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final List<Map> menuItems = [
      {
        'icon': Image.asset('assets/wheat.png', width: 65, height: 65),
        'title': 'Crop Recommendation',
        'color': const Color(0xffFEDD82),
        'route': '/crop-recommendation',
      },
      {
        'icon': Image.asset('assets/fertilizer.png', width: 65, height: 65),
        'title': 'Fertilizer Recommendation',
        'color': const Color(0xff7376FF),
        'route': '/fertilizer-recommendation',
      },
      {
        'icon': Image.asset('assets/pest.png', width: 65, height: 65),
        'title': 'Pest Disease Detection',
        'color': const Color(0xffFE93A4),
        'route': '/pest-disease-detection'
      },
      {
        'icon': Image.asset('assets/farmer.png', width: 65, height: 65),
        'title': 'Nearby Store Locator',
        'color': const Color(0xff00BDD5),
        'route': '/nearby-store-locator'
      },
    ];
    return Scaffold(
        backgroundColor: kWhite,
        body: CustomScrollView(
          slivers: [
            SliverAppBar(
              backgroundColor: kWhite,
              foregroundColor: Colors.black,
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.only(
                  bottomRight: Radius.circular(50),
                ),
              ),
              expandedHeight: 200.0,
              floating: false,
              pinned: true,
              flexibleSpace: FlexibleSpaceBar(
                centerTitle: false,
                background: Container(
                  decoration: BoxDecoration(
                    color: kprimaryColor,
                    borderRadius: const BorderRadius.only(
                      bottomRight: Radius.circular(50),
                    ),
                  ),
                  child: Stack(
                    clipBehavior: Clip.none,
                    children: [
                      Positioned(
                        top: 0,
                        left: 220,
                        child: Image.asset(
                          'assets/image.png',
                          fit: BoxFit.fitHeight,
                        ),
                      ),
                      Positioned(
                        top: 50,
                        right: 200,
                        child: Column(
                          children: [
                            const SizedBox(height: 40),
                            const Text(
                              'Welcome,',
                              style: TextStyle(
                                fontSize: 30,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            Obx(() {
                              return Text(
                                controller.userName.value,
                                style: const TextStyle(
                                  fontSize: 30,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.blue,
                                ),
                              );
                            }),
                          ],
                        ),
                      ),
                      // menu icon on the interference of the SliverToBoxAdapter and SliverAppBar
                      Positioned(
                          top: 150,
                          left: 300,
                          child: ChicletAnimatedButton(
                            backgroundColor: kbuttonColor,
                            child: Image.asset(
                              'assets/profile.png',
                              width: 30,
                              height: 30,
                            ),
                            onPressed: () {
                              // logout the user
                              controller.signOut();
                            },
                          )),
                    ],
                  ),
                ),
              ),
            ),
            SliverToBoxAdapter(
              child: Container(
                height: 700,
                decoration: BoxDecoration(
                  color: kprimaryColor,
                ),
                child: Container(
                  height: 700,
                  decoration: BoxDecoration(
                    color: kWhite,
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(50),
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.all(16.0),
                    child: GridView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: 10,
                        mainAxisSpacing: 10,
                      ),
                      itemCount: 4,
                      itemBuilder: (BuildContext context, int index) {
                        return Container(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Center(
                            child: ChicletAnimatedButton(
                              onPressed: () {
                                Get.toNamed(menuItems[index]['route']);
                              },
                              width: 150,
                              height: 150,
                              backgroundColor: menuItems[index]['color'],
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  menuItems[index]['icon'],
                                  const SizedBox(height: 10),
                                  Text(
                                    menuItems[index]['title'],
                                    style: const TextStyle(
                                      color: Color(0xff333333),
                                      fontSize: 16,
                                      fontFamily: 'Poppins-SemiBold',
                                      // fontWeight: FontWeight.semi,
                                    ),
                                    textAlign: TextAlign.center,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
              ),
            ),
          ],
        ));
  }
}
