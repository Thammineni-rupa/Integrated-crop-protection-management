// lib/presentation/pages/pest_disease_detection.dart

import 'package:AgroDoc/presentation/controllers/pest_disease_controller.dart';
import 'package:AgroDoc/presentation/widgets/output.dart';
import 'package:chiclet/chiclet.dart';

import 'package:flutter/material.dart';
import 'package:get/get.dart';

// users should upload an image and the model will predict the disease or pest

class PestDiseaseDetection extends GetView<PestDiseaseController> {
  const PestDiseaseDetection({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        title: const Text('Pest Disease Detection',
            style: TextStyle(color: Colors.white, fontSize: 20)),
        backgroundColor: Colors.green,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.white),
          onPressed: () {
            Get.back();
          },
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Container(
            height: Get.height / 1.2,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // upload an image to predict the Disease
                Obx(() {
                  return controller.isLoading.value
                      ? const CircularProgressIndicator()
                      : Center(
                          child: Column(
                            children: [
                              controller.uploadedImage.value == ""
                                  ? const SizedBox()
                                  : Image.network(
                                      controller.uploadedImage.value),
                              const SizedBox(height: 20),
                              ChicletAnimatedButton(
                                width: 200,
                                height: 50,
                                onPressed: () =>
                                    controller.uploadAndSendImage(),
                                child: const Text('Upload Image'),
                              ),
                            ],
                          ),
                        );
                }),

                const SizedBox(height: 20),
                Obx(() {
                  if (controller.isLoading.value) {
                    return const CircularProgressIndicator();
                  } else {
                    return outputDisplay(
                        output:
                            'Prediction: ${controller.statusMessage.value}');
                  }
                }),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
